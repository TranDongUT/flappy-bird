export const playing = (payload) => ({
  type: "PLAYING",
});
