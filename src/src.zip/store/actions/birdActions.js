export const fly = (payload) => ({
  type: "FLY",
});

export const fall = () => ({
  type: "FALL",
});
